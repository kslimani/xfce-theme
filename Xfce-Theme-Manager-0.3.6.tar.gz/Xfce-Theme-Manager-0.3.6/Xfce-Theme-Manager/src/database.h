/*
 *
 * K.D.Hedger 2012 <kdhedger68713@gmail.com>
 *
 * database.h
 */

#ifndef _DATABASE_
#define _DATABASE_

gpointer rebuildDB(gpointer data);

#endif
